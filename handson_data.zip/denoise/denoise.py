# -*- coding: utf-8 -*-
"""
Deep learning handson
Image superresolution using DnCNN and Win5-RB
@author: Masahiro Oda (Nagoya Univ.), Takeshi Hara (Gifu Univ.)

This is a part of the Deep learning sample code collection for MEDical image processing: DMED
DMED is proposed in:
小田昌宏，原武史，森健策，``医用画像処理のための深層学習サンプルコード集DMED,'' 日本コンピュータ外科学会誌 第27回日本コンピュータ外科学会大会特集号（JSCAS2018）, 2018

Denoising Convolutional Neural Network is proposed in:
Kai Zhang, Wangmeng Zuo, Yunjin Chen, Deyu Meng, Lei Zhang. Beyond a Gaussian Denoiser: Residual Learning of Deep CNN for Image Denoising, arXiv:1608.03981, 2016

Wide Inference Network is proposed in:
Peng Liu, Ruogu Fang. Wide Inference Network for Image Denoising via Learning Pixel-distribution Prior, arXiv:1707.05414, 2017
"""

import os
import cv2
import numpy as np
from keras.layers import Input, Conv2D, Add, BatchNormalization, Activation
from keras.models import Model
import keras.optimizers as optimizers
from tensorflow.python.keras import backend as K
import matplotlib.pyplot as plt

IMAGE_SIZE = 128
EPOCHS = 3


# ディレクトリ内の画像を読み込む
# inputpath: ディレクトリ文字列, imagesize: 画像サイズ, type_color: ColorかGray
def load_images(inputpath, imagesize, type_color):
    imglist = []

    for root, dirs, files in os.walk(inputpath):
        for fn in sorted(files):
            bn, ext = os.path.splitext(fn)
            if ext not in [".bmp", ".BMP", ".jpg", ".JPG", ".jpeg", ".JPEG", ".png", ".PNG"]:
                continue

            filename = os.path.join(root, fn)
            
            if type_color == 'Color':
                # カラー画像の場合
                testimage = cv2.imread(filename, cv2.IMREAD_COLOR)
                # サイズ変更
                height, width = testimage.shape[:2]
                testimage = cv2.resize(testimage, (imagesize, imagesize), interpolation = cv2.INTER_AREA)  #主に縮小するのでINTER_AREA使用
                testimage = np.asarray(testimage, dtype=np.float64)
                # 色チャンネル，高さ，幅に入れ替え．data_format="channels_first"を使うとき必要
                #testimage = testimage.transpose(2, 0, 1)
                # チャンネルをbgrの順からrgbの順に変更
                testimage = testimage[:,:,::-1]
            
            elif type_color == 'Gray':
                # グレースケール画像の場合
                testimage = cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
                # サイズ変更
                height, width = testimage.shape[:2]
                testimage = cv2.resize(testimage, (imagesize, imagesize), interpolation = cv2.INTER_AREA)  #主に縮小するのでINTER_AREA使用
                # チャンネルの次元がないので1次元追加する
                testimage = np.asarray([testimage], dtype=np.float64)
                testimage = np.asarray(testimage, dtype=np.float64).reshape((imagesize, imagesize, 1))
                # チャンネル，高さ，幅に入れ替え．data_format="channels_first"を使うとき必要
                #testimage = testimage.transpose(2, 0, 1)

            imglist.append(testimage)
    imgsdata = np.asarray(imglist, dtype=np.float32)

    return imgsdata, sorted(files)  # 画像リストとファイル名のリストを返す

# 指定ディレクトリに画像リストの画像を保存する
# savepath: ディレクトリ文字列, filenamelist: ファイル名リスト, imagelist: 画像リスト
def save_images(savepath, filenamelist, imagelist):
    for i, fn in enumerate(filenamelist):
        filename = os.path.join(savepath, fn)
        testimage = imagelist[i]
        testimage = testimage[:,:,::-1]
        cv2.imwrite(filename, testimage)


#%%
# データ準備
# 画像読み込み
# training用のノイズ画像と原画像読み込み
imagenoise_train, imagenoise_train_filenames = load_images("./train_noise/", IMAGE_SIZE, 'Gray')
image_train, image_train_filenames = load_images("./train/", IMAGE_SIZE, 'Gray')
# test用のノイズ画像と原画像読み込み
imagenoise_test, imagenoise_test_filenames = load_images("./test_noise/", IMAGE_SIZE, 'Gray')
image_test, image_test_filenames = load_images("./test/", IMAGE_SIZE, 'Gray')

# 画素値0-1正規化
imagenoise_train /= 255.0
image_train /= 255.0
imagenoise_test /= 255.0
image_test /= 255.0


#%%
# ネットワークの定義
# Denoising Convolutional Neural Network (DnCNN)
def network_dncnn():
    input_img = Input(shape=(IMAGE_SIZE, IMAGE_SIZE, 1))
    
    x = Conv2D(64, kernel_size=3, activation='relu', padding='same')(input_img)
    
    for i in range(15):
        x = Conv2D(64, kernel_size=3, padding='same')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
    
    x = Conv2D(1, kernel_size=3, activation='tanh', padding='same')(x)
    
    model = Model(input_img, x)
    
    return model

# DnCNN簡易版
def network_dncnn_simple():
    input_img = Input(shape=(IMAGE_SIZE, IMAGE_SIZE, 1))
    
    x = Conv2D(64, kernel_size=3, activation='relu', padding='same')(input_img)
    
    for i in range(3):
        x = Conv2D(64, kernel_size=3, padding='same')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
    
    x = Conv2D(1, kernel_size=3, activation='tanh', padding='same')(x)
    
    model = Model(input_img, x)
    
    return model

# Wide Inference Network (Win5-RB)
def network_win5rb():
    input_img = Input(shape=(IMAGE_SIZE, IMAGE_SIZE, 1))
    
    x = Conv2D(64, kernel_size=7, padding='same')(input_img)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    
    for i in range(3):
        x = Conv2D(64, kernel_size=7, padding='same')(x)
        x = BatchNormalization()(x)
        x = Activation('relu')(x)
    
    x = Conv2D(1, kernel_size=7, padding='same')(x)
    x = BatchNormalization()(x)
    x = Add()([x, input_img])
    
    model = Model(input_img, x)
    
    return model

model = network_dncnn_simple()

# ネットワークを表示
print(model.summary())


#%%
def psnr(y_true, y_pred):
    return -10*K.log(K.mean(K.flatten((y_true - y_pred))**2))/np.log(10)
    
# trainingの設定
adam = optimizers.Adam(lr=1e-3)
model.compile(loss='mean_squared_error', optimizer='adam', metrics=[psnr])

# training実行
# training用ノイズ画像と元画像でtrainingする．validation用にtest用のノイズ画像と元画像を使用する．
training = model.fit(imagenoise_train, image_train,
                     epochs=EPOCHS, batch_size=10, shuffle=True, validation_data=(imagenoise_test, image_test), verbose=1)


#%%
# training結果をファイルに保存
# ネットワーク定義保存
json_string = model.to_json()
open("denoise_model_json", "w").write(json_string)
# 重み
model.save_weights('denoise_weight_hdf5')

# 学習履歴グラフ表示
def plot_history(history):
    plt.plot(history.history['psnr'])
    plt.plot(history.history['val_psnr'])
    plt.title('model accuracy')
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    plt.legend(['psnr', 'val_psnr'], loc='lower right')
    plt.show()
    
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.xlabel('epoch')
    plt.ylabel('loss')
    plt.legend(['loss', 'val_loss'], loc='lower right')
    plt.show()
    
plot_history(training)


#%%
# test用ノイズ画像を用いた推定の実行
results = model.predict(imagenoise_test, verbose=1)

# 推定結果の画像表示
n = 5
plt.figure(figsize=(25, 10))
for i in range(n):
   # ノイズ画像
   ax = plt.subplot(2, n, i+1)
   plt.imshow(imagenoise_test[i].reshape(IMAGE_SIZE, IMAGE_SIZE))
   plt.gray()
   ax.get_xaxis().set_visible(False)
   ax.get_yaxis().set_visible(False)
   
   # 推定結果画像
   ax = plt.subplot(2, n, i+1+n)
   plt.imshow(results[i].reshape(IMAGE_SIZE, IMAGE_SIZE))
   plt.gray()
   ax.get_xaxis().set_visible(False)
   ax.get_yaxis().set_visible(False)
plt.show()

# 推定結果の画像をファイル保存
results *= 255.0    # 0-1の範囲の値が出力されるので見やすいように255倍する
save_images("./result/", imagenoise_test_filenames, results)
